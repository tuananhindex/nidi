<div class="DnnModule DnnModule-DNN_HTML DnnModule-505"><a name="505"></a><div id="dnn_ctr505_ContentPane"><!-- Start_Module_505 --><div id="dnn_ctr505_ModuleContent" class="DNNModuleContent ModDNNHTMLC">
    <div id="dnn_ctr505_HtmlModule_lblContent" class="Normal">
    <style type="text/css">
    .contact-phone {
    color: red;
    font-weight: bold;
    font-size: 32px;
    border: 1px solid #DDDDDD;
    border-radius: 5px;
    padding: 15px;
    }
    .contact-img{padding:5px 0 5px 0}
</style>
<div class="support-title">Tư vấn hỗ trợ khách hàng</div>
<div class="row-fluid center">
<div class="contact-phone">
1900 636 083
</div>
</div>
<div class="clear"></div>
<div class="row-fluid center">
<div class="contact-img">
<img alt="contact" src="<?php echo e(asset('assets/frontend/img/cskh.jpg')); ?>">
</div>
</div>
<div class="clear"></div>
<div class="row-fluid">
<div>T2 - T6: Từ 8h00 - 17h </div>
</div>
</div>

</div><!-- End_Module_505 --></div>
</div>