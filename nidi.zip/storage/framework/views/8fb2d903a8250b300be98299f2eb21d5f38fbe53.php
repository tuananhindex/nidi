<p><?php echo e($hoten); ?></p>
<p><?php echo e($email); ?></p>
<p><?php echo e($phone); ?></p>
<p><?php echo e($noidung); ?></p>