<div class="DnnModule DnnModule-MISACMS DnnModule-445">
<a name="445"></a>
<div class="DNNContainer Container4">
    <h4><span id="dnn_ctr445_dnnTITLE_titleLabel" class="ContainerTitle Title4">Tin tiêu điểm</span>


</h4>
    <div class="ContainerPane ContainerSpace">
    	<div id="dnn_ctr445_ContentPane"><!-- Start_Module_445 --><div id="dnn_ctr445_ModuleContent" class="DNNModuleContent ModMISACMSC">
	
<div id="pin_news">
    <ul>
        <li>
    <div class="img-news">
        <a href='../48786/9-buoc-de-hoan-thanh-bao-cao-quyet-toan-nhanh-nhat.htm'>
            <img alt="" class="img-pad img-responsive" src='../../../../ImageHandler_24.png' />
        </a>
    </div>
       <h2 class="pin-news-title"> <a class="link" title='9 bước để hoàn thành báo cáo quyết toán nhanh nhất' href='../48786/9-buoc-de-hoan-thanh-bao-cao-quyet-toan-nhanh-nhat.htm'>9 bước để hoàn thành báo cáo quyết toán nhanh nhất</a></h2>
<div class="clear"></div>
</li><li>
    <div class="img-news">
        <a href='../48840/Uu-dai-mua-Quyet-toan-khi-mua-phan-mem-ke-toan-MISA-SMENET-2015.htm'>
            <img alt="" class="img-pad img-responsive" src='../../../../ImageHandler_26.png' />
        </a>
    </div>
       <h2 class="pin-news-title"> <a class="link" title='Ưu đãi mùa Quyết toán khi mua phần mềm kế toán MISA SME.NET 2015' href='../48840/Uu-dai-mua-Quyet-toan-khi-mua-phan-mem-ke-toan-MISA-SMENET-2015.htm'>Ưu đãi mùa Quyết toán khi mua phần mềm kế toán MISA SME...</a></h2>
<div class="clear"></div>
</li><li>
    <div class="img-news">
        <a href='../50271/Tang-phan-mem-MISA-SMENET-2015-goi-Starter-cho-doanh-nghiep-thanh-lap-moi-nam-2016.htm'>
            <img alt="" class="img-pad img-responsive" src='../../../../ImageHandler_25.png' />
        </a>
    </div>
       <h2 class="pin-news-title"> <a class="link" title='Tặng phần mềm MISA SME.NET 2015 gói Starter cho doanh nghiệp thành lập mới năm 2016' href='../50271/Tang-phan-mem-MISA-SMENET-2015-goi-Starter-cho-doanh-nghiep-thanh-lap-moi-nam-2016.htm'>Tặng phần mềm MISA SME.NET 2015 gói Starter cho doanh n...</a></h2>
<div class="clear"></div>
</li><li>
    <div class="img-news">
        <a href='../48863/Tai-lieu-huong-dan-quyet-toan-ke-toan-ngan-sach-Xa.htm'>
            <img alt="" class="img-pad img-responsive" src='../../../../ImageHandler_27.png' />
        </a>
    </div>
       <h2 class="pin-news-title"> <a class="link" title='Tài liệu hướng dẫn quyết toán kế toán ngân sách Xã' href='../48863/Tai-lieu-huong-dan-quyet-toan-ke-toan-ngan-sach-Xa.htm'>Tài liệu hướng dẫn quyết toán kế toán ngân sách Xã</a></h2>
<div class="clear"></div>
</li><li>
    <div class="img-news">
        <a href='../52729/Thu-tuong-Nguyen-Xuan-Phuc-khen-ngoi-su-pho-bien-va-uy-tin-cua-phan-mem-MISA.htm'>
            <img alt="" class="img-pad img-responsive" src='../../../../ImageHandler_30.png' />
        </a>
    </div>
       <h2 class="pin-news-title"> <a class="link" title='Thủ tướng Nguyễn Xuân Phúc khen ngợi sự phổ biến và uy tín của phần mềm MISA' href='../52729/Thu-tuong-Nguyen-Xuan-Phuc-khen-ngoi-su-pho-bien-va-uy-tin-cua-phan-mem-MISA.htm'>Thủ tướng Nguyễn Xuân Phúc khen ngợi sự phổ biến và uy ...</a></h2>
<div class="clear"></div>
</li>
    </ul>
</div>






</div><!-- End_Module_445 --></div>
	</div>
	<div class="clear"></div>
</div>
<div class="ContainerSpace2"></div>
</div>