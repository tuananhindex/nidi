<div class="DnnModule DnnModule-DNN_HTML DnnModule-504"><a name="504"></a>
<div class="DNNContainer Container4">
    <h4><span id="dnn_ctr504_dnnTITLE_titleLabel" class="ContainerTitle Title4">Thông tin liên hệ</span>


</h4>
    <div class="ContainerPane ContainerSpace">
    	<div id="dnn_ctr504_ContentPane"><!-- Start_Module_504 --><div id="dnn_ctr504_ModuleContent" class="DNNModuleContent ModDNNHTMLC">
	<div id="dnn_ctr504_HtmlModule_lblContent" class="Normal">
	<style type="text/css">
    .padtop10 {
    padding-top: 10px;
    }
</style>
<div class="contact-info">
<div class="row-fluid">
Hà Nội (Khối DN): (04) 3762 7891
</div>
<div class="clear"></div>
<div class="row-fluid">
Hà Nội (Khối HCSN): (04) 3795 9595
</div>
<div class="clear"></div>
<div class="row-fluid">
Đà Nẵng: (0511) 366 7555
</div>
<div class="clear"></div>
<div class="row-fluid">
Buôn Ma Thuột: (0500) 381 7400
</div>
<div class="clear"></div>
<div class="row-fluid">
TP Hồ Chí Minh: (08) 5431 8318
</div>
<div class="clear"></div>
<div class="row-fluid">
Cần Thơ: (0710) 376 6468
</div>
<div class="clear"></div>
<div class="row-fluid padtop10 ">
<a href="Tin-tuc.htm#" class="link-cls right">Xem thêm
</a>
</div>
</div>
</div>

</div><!-- End_Module_504 --></div>
	</div>
	<div class="clear"></div>
</div>
<div class="ContainerSpace2"></div></div>